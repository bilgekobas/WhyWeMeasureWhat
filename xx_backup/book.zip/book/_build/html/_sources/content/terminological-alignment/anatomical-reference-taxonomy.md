# Anatomical reference taxonomy

This section compiles the anatomical sites used for skin-temperature measurement, standardised into 19 body regions. Each site may include left/right or anterior/posterior counterparts; these are only specified when relevant.\
Letters A--U from the previous chapter, 4.2 Mean skin temperature formulas are retained solely to map historical formulas to the standardised regions shown in the below Figure and Table.

```{figure} C:/Users/kobas/00_Repos/2511_WhyWeMeasureWhat_Git/book/assets/figures/skin-temp-sites.jpeg
:name: fig-skin-temp-sites
:width: 5.5in
:alt: Body sites for skin temperature measurement

Skin temperature measurement sites. Letter annotations refer to the matching measurement regions in Mean Skin Temperature calculation formulas. Regions correspond to Table 8. Each may be subdivided by side (L/R) or aspect (A = anterior, P = posterior, M = midline).\
Black points indicate specific aspects of measurement sites as per MST formulas. Pink points indicate other possible sites, as seen in current practices.`.
```

:::{table} General anatomical reference taxonomy for physiological measurements grouped by anatomical region, including mappings to mean skin temperature (MST) formula codes, commonly used aliases, and interpretive notes.

|| **Body domain** | **Region code** | **Site / region** | **Anatomical class** | **Laterality / aspect** | **Common aliases / variants** | **Typical modalities / signals** | **MST code(s)** | **Notes** |
|---|---|---|---|---|---|---|---|---|
| **Head** | 1 | Forehead | Surface | Anterior midline | Brow, temple | Skin temperature, IRT, zero-heat-flux CBT | A | Common in MST and facial thermography |
|  | 2 | Nose | Surface | Midline | Nasal dorsum, alar region | IRT, facial temperature | — | Relevant for respiratory heat exchange |
|  | 3 | Cheek | Surface | Left / right | Malar region, zygomatic arch | Skin temperature, IRT | B | Common in IRT; not always included in older MST sets |
|  | 4 | Neck | Surface | Left / right / posterior | Sternocleidomastoid, nape, lateral neck, nuchal area | Skin temperature, IRT, wearable temperature | C | Exact placement should be specified |
|  | 5 | Ear canal / tympanic site | Cavity | Left / right | Aural canal, tympanic canal | Core body temperature | — | Distinguish ear canal measurement from true tympanic measurement |
|  | 6 | Earlobe | Surface | Left / right | Auricular lobe | PPG, pulse oximetry, temperature | — | Sometimes preferred over finger because of local perfusion stability |
|  | 7 | Oral cavity | Cavity | Sublingual / oral | Sublingual, oral temperature | Core body temperature proxy | — | Should distinguish oral vs sublingual |
| **Trunk** | 8 | Chest | Surface | Left / right / midline | Pectoral region, sternum, thorax | Skin temperature, ECG, respiration | K | May refer to sternum or lateral chest; must be specified |
|  | 9 | Abdomen | Surface | Midline / lateral | Umbilical region, epigastric, central abdomen | Skin temperature, IRT | M | Surface abdomen distinct from gastrointestinal internal site |
|  | 10 | Back | Surface | Left / right / midline | Scapular, interscapular, upper thoracic region | Skin temperature, IRT | J | Frequently confused with lumbar; should be distinguished |
|  | 11 | Lumbar | Surface | Left / right / midline | Lumbar, flank, lumbosacral region | Skin temperature, IRT | L | Lower posterior trunk; often merged with “back” in reporting |
|  | 12 | Buttocks | Surface | Left / right | Gluteal region | Skin temperature | N | Included in extended body-surface formulas |
|  | 13 | Gastrointestinal tract | Internal | — | GI lumen, intestinal site | CBT pill / ingestible telemetry | — | Internal site; not anatomically equivalent to surface abdomen |
|  | 14 | Oesophagus | Cavity / internal | — | Esophageal site | Core body temperature | — | Insertion depth should always be reported |
|  | 15 | Rectum | Cavity | — | Rectal site | Core body temperature | — | Depth of insertion strongly affects comparability |
|  | 16 | Bladder | Internal | — | Vesical site | Core body temperature | — | Mostly clinical / catheter-based |
|  | 17 | Pulmonary artery | Internal | — | PA catheter site | Core body temperature | — | Clinical gold standard; highly invasive |
| **Upper limb** | 18 | Upper arm | Surface | Left / right | Biceps, triceps, deltoid region | Skin temperature, cuff BP, wearable sensing | D | Should distinguish upper arm skin vs brachial cuff site |
|  | 19 | Elbow | Surface | Left / right | Cubital fossa, olecranon | Skin temperature | E | Anterior and posterior elbow are not equivalent |
|  | 20 | Forearm | Surface | Left / right | Antebrachial region | Skin temperature, PPG, EDA, IRT | F | Widely used due to accessibility |
|  | 21 | Wrist | Surface | Left / right; volar / dorsal | Carpal region, radial wrist, volar wrist | PPG, skin temperature, cuffless BP | — | Exact side and surface should be specified |
|  | 22 | Hand | Surface | Left / right; palmar / dorsal | Dorsum of hand, back of hand, palm | Skin temperature, EDA, IRT | G, H, I | Different formulas distinguish palm and dorsum |
|  | 23 | Finger | Surface | Left / right; digit-specific | Fingertip, phalanx, digital area | PPG, SpO₂, skin temperature, EDA | — | Highly vasomotor-sensitive; digit and side should be reported |
| **Lower limb** | 24 | Thigh | Surface | Anterior / posterior; left / right | Quadriceps, hamstring | Skin temperature, IRT | O, P | Anterior and posterior sites should be distinguished |
|  | 25 | Lower leg | Surface | Anterior / posterior; left / right | Shin, tibial region, calf, gastrocnemius | Skin temperature, IRT | Q, R | Calf and shin often conflated in the literature |
|  | 26 | Ankle | Surface | Left / right; medial / lateral / posterior | Malleolar area, Achilles region | Skin temperature, distal gradient analysis | — | Exact aspect matters substantially |
|  | 27 | Foot dorsum | Surface | Left / right | Instep, dorsal foot | Skin temperature, IRT | S, T | Dorsal foot should be separated from plantar foot |
|  | 28 | Sole / plantar foot | Surface | Left / right | Plantar surface | Skin temperature, pressure, sweat | U | Plantar surface not equivalent to dorsal foot |
:::