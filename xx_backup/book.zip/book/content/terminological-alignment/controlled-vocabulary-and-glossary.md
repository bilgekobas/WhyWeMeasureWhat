# Controlled vocabulary and glossary

This glossary focuses on physiological measurements and related methodological terminology used in thermal-environment research. It does not attempt to reproduce established built-environment terminology for environmental variables such as air temperature, operative temperature, or relative humidity, which are already well standardized elsewhere. Instead, it concentrates on terms that are used inconsistently across thermal physiology, environmental ergonomics, and measurement practice, especially where site, method, or derivation substantially affect interpretation.

